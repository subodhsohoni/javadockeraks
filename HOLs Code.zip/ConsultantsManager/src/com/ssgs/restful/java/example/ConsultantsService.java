package com.ssgs.restful.java.example;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/ConsultantsService")
public class ConsultantsService {
	
	ConsultantsDAO consultantsDAO = new ConsultantsDAO();  
	   @GET 
	   @Path("/consultants") 
	   @Produces(MediaType.TEXT_HTML) 
	   public String getConsultants(){ 
	      return consultantsDAO.getAllConsultants(); 
	   }  
}
