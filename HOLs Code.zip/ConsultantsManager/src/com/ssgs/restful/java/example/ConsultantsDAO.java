package com.ssgs.restful.java.example;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.ServletContext;
import javax.ws.rs.core.Context;


public class ConsultantsDAO {
	@Context
	ServletContext context;
	@SuppressWarnings("unchecked")
	public String getAllConsultants(){
//		List<Consultant> ConsultantList = new ArrayList<Consultant>();
//		Consultant consultant = new Consultant("Subodh", "Azure DevOps");
//		ConsultantList.add(consultant);
//		try {
//			//File file = new File("/WEB-INF/Consultants.xml");
//			InputStream fis = context.getResourceAsStream("/WEB-INF/Consultants.xml"); 
//            ObjectInputStream ois = new ObjectInputStream(fis); 
//            ConsultantList = ((List<Consultant>) ois.readObject()); 
//            ois.close(); 
//	      } catch (IOException e) { 
//	         e.printStackTrace(); 
//	      } catch (ClassNotFoundException e) { 
//	         e.printStackTrace(); 
//	      }   
      return "<html><head></head><body>Subodh, Azure DevOps</body></html>";		
	}
}
