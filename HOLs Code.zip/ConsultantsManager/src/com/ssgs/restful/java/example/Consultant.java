package com.ssgs.restful.java.example;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;

public class Consultant implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Consultant() {}
	public String name, expertise;
	public Consultant(String name, String expertise) {
		this.name = name;
		this.expertise = expertise;
	}
	public String getName() { 
	      return name; 
	   } 
	   @XmlElement
	   public void setName(String name) { 
	      this.name = name; 
	   } 
	   public String getExpertise() { 
	      return expertise; 
	   } 
	   @XmlElement 
	   public void setExpertise(String expertise) { 
	      this.expertise = expertise; 
	   }   
}
